# Cassandra Java Assignment: Controller

Use this package as a place to create any business services.

### Note:

This package exists solely for your convenience.  You are not required to add classes to this package.  Please feel free to bundle
the classes within your implementation in a way that makes sense to you.
