# Cassandra Java Assignment: DAO

Use this package as a place to create any Data Access Objects.

### Note:

This package exists solely for your convenience.  You are not required to add classes to this package.  Please feel free to bundle
the classes within your implementation in a way that makes sense to you.
